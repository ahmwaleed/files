from django.contrib import admin
from .models import student,studentprofile
# Register your models here.
admin.site.register(student)
admin.site.register(studentprofile)